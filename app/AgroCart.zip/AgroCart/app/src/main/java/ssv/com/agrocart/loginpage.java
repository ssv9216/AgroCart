package ssv.com.agrocart;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class loginpage extends AppCompatActivity{

    public EditText etPhone, etPass;
    public Button btnLogin;
    


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);

        etPhone = findViewById(R.id.login_etPhone);
        etPass = findViewById(R.id.login_etPass);
        btnLogin = findViewById(R.id.login_btnLogin);
        
        

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                checkDetail();

            }
        });


    }



    public void checkDetail() {
       if(!etPhone.getText().toString().equals("") && !etPass.getText().toString().equals("")){
//           fetchDatafromDb();
            if(etPhone.getText().toString().equals("123456") && etPass.getText().toString().equals("123456") ){

                gotoHomePage();


            }else{
            Toast.makeText(this, "User Not Found", Toast.LENGTH_SHORT).show();
            fetchDatafromDb();
            }
       }
       else{
           Toast.makeText(this, "Fill All detail properly", Toast.LENGTH_SHORT).show();
       }

    }
    private void fetchDatafromDb() {
        RegisterUsersDB dbHelper = new RegisterUsersDB(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor c= db.query("User_table",null,null,null,null,null,null);
        c.moveToLast();
        Toast.makeText(this, "Name Of User = "+c.getString(3), Toast.LENGTH_SHORT).show();
//        long r =RegisterUser.ROW;
//        long r = 1;
//        if(r > 0){
//            for (int zero= 0 ; zero < r; zero--){
//                c.moveToPosition(5);
//                int number =Integer.parseInt(c.getString((int) (r)));
//                c.moveToPosition(2);
//                String pass = c.getString((int) r);
//                if(number == Integer.parseInt(etPhone.getText().toString()) && pass.equals(etPass.getText().toString())){
//                    gotoHomePage();
//                }
//                else
//                {
//                    Toast.makeText(this, "User not Found", Toast.LENGTH_SHORT).show();
//                }
//
//            }
//        }else
//        {
//            Toast.makeText(this, "Database is empty!!", Toast.LENGTH_SHORT).show();
//        }

    }
    private void gotoHomePage() {
        Toast.makeText(this, "Welcome", Toast.LENGTH_SHORT).show();
        final Intent i = new Intent(this,HomePage.class);
        startActivity(i);
        finish();
        SharedPreferences prefs= PreferenceManager.getDefaultSharedPreferences(this);
        prefs.edit().putBoolean("isLogin",true).apply();
    }
    }
