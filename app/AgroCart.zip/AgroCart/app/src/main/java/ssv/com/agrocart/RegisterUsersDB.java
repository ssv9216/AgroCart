package ssv.com.agrocart;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class RegisterUsersDB extends SQLiteOpenHelper{

    public RegisterUsersDB(Context context) {
        super(context, "User_table", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table User_table(u_id Int, Email Varchar, Password Varchar, u_name Varchar, contact Int, district Varchar, taluka Varchar, village Varchar)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
