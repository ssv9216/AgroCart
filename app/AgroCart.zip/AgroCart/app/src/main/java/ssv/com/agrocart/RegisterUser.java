package ssv.com.agrocart;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterUser extends AppCompatActivity {
//    protected static long ROW = 0;
    public EditText etName,etPhone,etState, etDist, etTaluka, etVillage, etPass, etConfPass, etEmail;
    public Button btnSignUp;
    private ProgressDialog progressDialog;
//    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        etState = findViewById(R.id.etState);
        etDist= findViewById(R.id.etDist);
        etTaluka= findViewById(R.id.etTaluka);
        etVillage= findViewById(R.id.etVillage);
        etPass = findViewById(R.id.etPass);
        etConfPass = findViewById(R.id.etConfPass);

        
        
        btnSignUp = findViewById(R.id.signUp);

        progressDialog = new ProgressDialog(this);
//        firebaseAuth = FirebaseAuth.getInstance();

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String name = etName.getText().toString();
                final String phone = etPhone.getText().toString();
                final String state = etState.getText().toString();
                final String Dist = etDist.getText().toString();
                final String taluka = etTaluka.getText().toString();
                final String village = etVillage.getText().toString();
                final String pass = etPass.getText().toString();
                final String confPass = etConfPass.getText().toString();
                final String Email = etEmail.getText().toString();



                if (!Email.equals("") && !Email.equals(".") && !name.equals("") && !name.equals(".") && !phone.equals("") && !state.equals("") && !Dist.equals("") && !taluka.equals("") && !village.equals("") && !pass.equals("") && !confPass.equals("")) {
                    if (phone.length() != 10) {

                        Toast.makeText(RegisterUser.this, "number should be in 10 digit ", Toast.LENGTH_SHORT).show();
                    } else {
                        if (!pass.equals(confPass) && pass.length() <= 8) {
                            Toast.makeText(RegisterUser.this, "password must be same and greater than 6 letter", Toast.LENGTH_SHORT).show();
                        } else {
//                            storeToDb();
                            Toast.makeText(RegisterUser.this, "Welcome " + name, Toast.LENGTH_SHORT).show();
                            progressDialog.show();
//                            registerUser();

                        }
                    }
                } else {
                    Toast.makeText(RegisterUser.this, "Enter Detail Properly", Toast.LENGTH_SHORT).show();
                }
            }




        });
    }

//    private void registerUser() {
//
//        firebaseAuth.createUserWithEmailAndPassword(etEmail.getText().toString(), etPass.getText().toString())
//                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//                        if (task.isSuccessful()){
//                            Toast.makeText(RegisterUser.this, "success", Toast.LENGTH_SHORT).show();
//                        }
//                        else{
//                            Toast.makeText(RegisterUser.this, "Try again", Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                });
//    }
}